def game_parity_check():
    print('Test function game_parity_check')


def main():
    game_parity_check()


if __name__ == "__main__":
    main()