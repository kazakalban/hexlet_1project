[![Maintainability](https://api.codeclimate.com/v1/badges/fb65680623d9149df103/maintainability)](https://codeclimate.com/github/kazakalban/python-project-49/maintainability)


Hello Hexlet my first course
This project is my first in Hexlet 

Don't worry my English is bad))


test github 19.11.2024


show 1-project 5- step 
[![asciicast](https://asciinema.org/a/F7SH3ltXwWMXs7ckCgL1FnUWk.svg)](https://asciinema.org/a/F7SH3ltXwWMXs7ckCgL1FnUWk)

show 1-project 6-step
[![asciicast](https://asciinema.org/a/Q4BuVghsYnfT28PHk9Y2CgYm8.svg)](https://asciinema.org/a/Q4BuVghsYnfT28PHk9Y2CgYm8)
