from brain_games.scripts.brain_games import main as hello_main 

def game_parity_check():
    print('Answer "yes" if the number is even, otherwise answer "no".')
    


def main():
    hello_main()
    game_parity_check()


if __name__ == "__main__":
    main()